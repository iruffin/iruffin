    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

package ruffiniversonproject1;

/**
 *
 * @author Ivey
 */
public class RegularMember {
   private int booksBought;
   private int cdsBought;
   private int dvdsBought;
   private boolean isMember;
   private double moneySpent;
   private double fee;
   private int daysTilPayment;
   private double bookPrice = 5;
   private double cdPrice = 5;
   private double dvdPrice = 6;
   private String firstName;
   private String lastName;
   private int memberNum = 0;
   private String paymentMethod;
   
   //CREATES A REGULAR MEMBER
   public RegularMember(int booksBought, int cdsBought, int dvdsBought, boolean isMember, String firstName, String lastName, int memberNum){
        this.booksBought = booksBought;
        this.cdsBought = cdsBought;
        this.dvdsBought = dvdsBought;
        this.isMember = isMember;
        this.moneySpent = getMoneySpent(booksBought, cdsBought, dvdsBought);
        this.firstName = firstName;
        this.lastName = lastName;
        this.memberNum = memberNum;
   }

   //CREATES A PREMIUM MEMBER
   public RegularMember(int booksBought, int cdsBought, int dvdsBought, boolean isMember, String firstName, String lastName, double fee, int memberNum, int daysTilPayment, String paymentMethod){
        this.booksBought = booksBought;
        this.cdsBought = cdsBought;
        this.dvdsBought = dvdsBought;
        this.isMember = isMember;
        this.fee = fee;
        this.daysTilPayment = daysTilPayment;
        this.moneySpent = getMoneySpent(booksBought, cdsBought, dvdsBought);
        this.paymentMethod = paymentMethod;
        this.memberNum = memberNum;
        incrementMemberNum();
   }

   //GETTERS
   
   //returns books bought
   public int getBooksBought(){
        return booksBought;
   }
    
   //returns cd's bought
   public int getCdsBought(){
        return cdsBought;
   }

   //returns dvds bought
   public int getDvdsBought(){
        return dvdsBought;
   }

   //returns status of member
   public boolean getIsMember(){
        return isMember;
   }

   //returns total money spent
   public double getMoneySpent(){
        return moneySpent;
   }

   //returns money spent from total costs
   public double getMoneySpent(int booksBought, int cdsBought, int dvdsBought){
        return (booksBought * bookPrice) + (cdsBought * cdPrice) + (dvdsBought * dvdPrice);   
   }

   //returns fee due for the month
   public double getFee(){
        return fee;
   }

   //returns days until next payment is due
   public int getDaysTilPayment(){
        return daysTilPayment;
   }

   //returns the book price
   public double getBookPrice(){
        return bookPrice;
   }

   //returns the cd price
   public double getCdPrice(){
        return cdPrice;
   }

   //returns the dvd price
   public double getDvdPrice(){
        return dvdPrice;
   }

   //returns the first name
   public String getFirstName(){
        return firstName;
   }

   //returns the last name
   public String getLastName(){
        return lastName;
   }

   //returns the member's number
   public int getMemberNum(){
        return memberNum;
   }

   //returns the payment method
   public String getPaymentMethod(){  
        return paymentMethod;
   }

   //SETTERS

   //sets how many books bought
   public void setBooksBought(int booksBought){
        this.booksBought = booksBought;
   }

   //sets how many cds bought
   public void setCdsBought(int cdsBought){
        this.cdsBought = cdsBought;
   }

   //sets how mnay dvds bought
   public void setDvdsBought(int dvdsBought){
        this.dvdsBought = dvdsBought;
   }

   //sets member status to true or false
   public void setIsMember(boolean isMember){
        this.isMember = isMember;
   }

   //sets the amount of money spent
   public void setMoneySpent(double moneySpent){    
        this.moneySpent = moneySpent;
   }

   //sets the fee to be paid by premium members
   public void setFee(double fee){
        this.fee = fee;
   }

   //sets the days until next payment is due
   public void setDaysTilPayment(int daysTilPayment){
        this.daysTilPayment = daysTilPayment;
   }

   //sets the price of the books
   public void setBookPrice(double bookPrice){
        this.bookPrice = bookPrice;
   }

   //sets the price of the cd's
   public void setCdPrice(double cdPrice){
        this.cdPrice = cdPrice;
   }


   //sets the price of the dvd's
   public void setDvdPrice(double dvdPrice){
        this.dvdPrice = dvdPrice;
   }

   //sets the first name
   public void setFirstName(String firstName){
        this.firstName = firstName;
   }

   //sets the last name
   public void setLastName(String lastName){
        this.lastName = lastName;
   }

   //METHODS

   //increases member number by 1
   public void incrementMemberNum(){
        memberNum++;
   }
        

}
