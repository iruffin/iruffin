/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ruffiniversonproject1;
import java.util.Scanner;

/**
 *
 * @author Ivey
 */
public class RuffinIversonProject1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        Scanner user = new Scanner(System.in);
        BookStore b = new BookStore();
        
        //type 1 as the input in if you select option 1, for an already premade account
        int i = 1;
        while(i != 5 ){
            //Menu for ordering items from books
            System.out.println("\t 1. Purchase Items.");
            System.out.println("\t 2. Check if account exists.");
            System.out.println("\t 3. Check money spent on account.");
            System.out.println("\t 4. Create new account.");
            System.out.println("\t 5. Exit.");

            switch(i = user.nextInt()){

                case 1:
                    System.out.println("What is your member number?");
                    int memberNum = user.nextInt();
                    if(b.findMember(memberNum) == false){
                        System.out.println("There is no such account. Please make an Account;");
                    }else{
                        System.out.println("What is your member number?");
                        memberNum = user.nextInt();
                        System.out.println("How many books do you want?");
                        int books = user.nextInt();
                        System.out.println("How many CD's do you want?");
                        int cds = user.nextInt();
                        System.out.println("How many DVD's do you want?");
                        int dvds = user.nextInt();
                        System.out.println("Your total is $" +b.makePurchase(books, cds, dvds, memberNum));
                    }
                break;

                case 2:
                    System.out.println("What's your member number?");
                    memberNum = user.nextInt();
                    if(b.findMember(memberNum) == false){
                        System.out.println("No account was found.");
                    }else{
                        System.out.println("This account exists. Your account number is: " +memberNum);
                    }

                break;

                case 3:
                    System.out.println("What's your member number?");
                    memberNum = user.nextInt();
                    if(b.findMember(memberNum) == false){
                        System.out.println("No account was found with this member number. Please make an account.");
                    }else{
                        System.out.println("You have spent: $:" +b.findMoneySpent(memberNum));
                    }
                    
                break;

                case 4:
                    System.out.println("Whats your first name?");
                    String firstName = user.next();
                    System.out.println("What's your last name?");
                    String lastName = user.next();
                    System.out.println("Would you like to upgrade to a premium account(type yes or no)?");
                    String answer = user.next();
                    if(answer.charAt(0) == 'n'){
                        b.customer.add(new RegularMember(0, 0, 0, false, firstName, lastName, b.getMemberNum()));
                        b.incrementMemberNum();
                        System.out.println("Congrats on making an account. Your new account number is: "+(b.getMemberNum()-1));
                    }else if(answer.charAt(0) == 'y'){
                        System.out.println("What is your payment method(type cash or card)?");
                        String paymentMethod = user.next();
                        b.customer.add(new RegularMember(0, 0, 0, true, firstName, lastName, 10, b.getMemberNum(), 30, paymentMethod));
                        b.incrementMemberNum();
                        System.out.println("Congrats on making an account. Your new account number is: "+(b.getMemberNum()-1));
                    }
                break;

                case 5:
                break;
            } 
        }
    }
}
