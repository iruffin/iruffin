/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ruffiniversonproject1;
import java.util.ArrayList;

/**
 *
 * @author Ivey
 */
public class BookStore {
    //VARIABLES
    private int bookStorage = 500;
    private int cdStorage = 500;
    private int dvdStorage = 500;
    public RegularMember member;
    private double fee = 10;
    private int daysTilPayment = 5;
    private int memberNum = 0;
    
     //CONSTRUCTORS
    
    //used to store customers in the store when they make an account
    public ArrayList<RegularMember> customer = new ArrayList<RegularMember>();
    
    //bookstore automatically comes with one regular member and a premium member
    public BookStore(){
        customer.add(new RegularMember(0, 0, 0, false, "Iverson", "Ruffin", getMemberNum()));
        incrementMemberNum();
        customer.add(new RegularMember(0, 0, 0, false, "Rj", "Nig", getMemberNum()));
        incrementMemberNum();
    }
    
    //GETTERS

    //returns the book storage amount
    public int getBookStorage(){
        return bookStorage;
    }

    //returns the cd storage amount
    public int getCdStorage(){
        return cdStorage;
    }

    //returns the dvd storage amount
    public int getDvdStorage(){
        return dvdStorage;
    }

    //returns the fee
    public double getFee(){
        return fee;
    }

    //returns days until next payment
    public int getDaysTilPayment(){
        return daysTilPayment;
    }

    //returns the member's number
    public int getMemberNum(){
        return memberNum;
    }

    //SETTERS

    //sets amount of books in storage
    public void setBookStorage(int bookStorage){
        this.bookStorage = bookStorage;
    }

    //sets amount of cd's in storage
    public void setCdStorage(int cdStorage){
        this.cdStorage = cdStorage;
    }

    //sets the amount of dvd's in storage
    public void setDvdStorage(int dvdStorage){
        this.dvdStorage = dvdStorage;
    }
    
    //sets the fee for the month
    public void setFee(double fee){
        this.fee = fee;
    }

    //sets days until next payment is due
    public void setDaysTilPayment(int daysTilPayment){
        this.daysTilPayment = daysTilPayment;
    }
    
    //METHODS
    
    //allows the user to purchase books and add to their account
    public double makePurchase(int books, int cds, int dvds, int memberNum){
        member = customer.get(memberNum);
        double moneySpent = member.getMoneySpent(books, cds, dvds);
        bookStorage = bookStorage - books;
        cdStorage = cdStorage - cds;
        dvdStorage = dvdStorage - dvds;
        member.setMoneySpent(moneySpent);
        
        return member.getMoneySpent();
    }

    //finds member in the system, if not, the system returns -1
    public boolean findMember(int memberNum){
        //returns -1 if member is not found
        int error = -1;

        for(int i = 0; i < customer.size(); i++){
            member = customer.get(i);
            if(member.getMemberNum() == memberNum){
                return true;
            }
        }
        return false;
    }

    //Tells user how much their account has spent in total
    public double findMoneySpent(int memberNum){
        //returns -1 if member is not found
        double error = -1;

        return customer.get(memberNum).getMoneySpent();
    }

    public void incrementMemberNum(){
        memberNum++;
   }

}
