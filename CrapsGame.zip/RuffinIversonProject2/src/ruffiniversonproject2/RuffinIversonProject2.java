/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ruffiniversonproject2;

/**
 *
 * @author Ivey
 */
public class RuffinIversonProject2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CrapsGame p = new CrapsGame(0,0,1,0,0,0,0,0);
        
        
        for(int round = 1; round <= 100000; round++){
            p.setRollNum(0);
            p.rollDice();
            int total = p.getDieTotal();
            p.printRoundInfo(round);
            
            switch(total){
                case 2: case 3: case 12:
                    p.incrementLosses();
                    p.printGameResults1(round);
                    break;
                case 7: case 11:
                    p.incrementWins();
                    p.printGameResults2(round);
                    break;
                default:
                    p.setRoundPoint(total);
                    p.printRoundPoint(round);
                    while(p.getDieTotal() != 7 || p.getDieTotal() != p.getRoundPoint()){
                        p.rollDice();
                        p.printRoundInfo(round);
                        if(p.getDieTotal() == 7){
                            p.incrementWins();
                            p.printGameResults2(round);
                            break;
                        }else if(p.getDieTotal() == p.getRoundPoint()){
                            p.incrementLosses();
                            p.printGameResults1(round);
                            break;
                        }
                    }
            }
        }
        System.out.println("Overall:\n"+p.getWins()+ " wins, " +p.getLosses()+ " losses");
    }
}
