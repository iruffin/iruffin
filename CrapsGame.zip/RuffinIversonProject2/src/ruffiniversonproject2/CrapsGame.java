/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ruffiniversonproject2;
import java.util.Random;
/**
 *
 * @author Ivey
 */
public class CrapsGame {
    private int dice1;
    private int dice2;
    private int roundNumber;
    private int roundPoint;
    private int dieTotal;
    private int wins = 0;
    private int losses = 0;
    private int rollNum = 0;
    private int[] diceOptions = {1,2,3,4,5,6};

    //CONSTRUCTORS
    public CrapsGame(int dice1, int dice2, int roundNumber, int roundPoint, int dieTotal, int wins, int losses, int rollNum){
        this.dice1 = dice1;
        this.dice2 = dice2;
        this.roundNumber = roundNumber;
        this.roundPoint = roundPoint;
        this.dieTotal = dieTotal;
        this.wins = wins;
        this.losses = losses;
        this.rollNum = rollNum;
        
    }

    Random r = new Random();
    
    //GETTERS
    public int getDice1(){
        return dice1;
    }

    public int getDice2(){
        return dice2;
    }

    public int getRoundNumber(){
        return roundNumber;
    }

    public int getRoundPoint(){
        return roundPoint;
    }

    public int getDieTotal(){
        return dice1 + dice2;
    }

    public int getWins(){
        return wins;
    }

    public int getLosses(){
        return losses;
    }

    public int getRollNum(){
        return rollNum;
    }

    //SETTERS
    public void setDice1(int dice1){
        this.dice1 = dice1;
    }

    public void setDice2(int dice2){
        this.dice2 = dice2;
    }

    public void setRoundNumber(int roundNumber){
        this.roundNumber = roundNumber;
    }

    public void setRoundPoint(int roundPoint){
        this.roundPoint = roundPoint;
    }

    public void setDieTotal(int dice1, int dice2){
        this.dieTotal = dice1 + dice2;
    }

    public void setWins(int wins){
        this.wins = wins;
    }

    public void setLosses(int losses){
        this.losses = losses;
    }

    public void setRollNum(int num){
        this.rollNum = num;
    }

    //METHODS
    public void rollDice(){
        dice1 = diceOptions[r.nextInt(6)];
        dice2 = diceOptions[r.nextInt(6)];
        setDieTotal(dice1, dice2);
        rollNum++;
    }

    public void incrementWins(){
        wins++;
    }

    public void incrementLosses(){
        losses++;
    }

    public void printRoundInfo(int num){
        if(num <= 10){
            System.out.println("Round " +num+ ", Roll " +rollNum+ " -- Die1: " +dice1+ ", Die2: " +dice2+ " -- Total: " +dieTotal);
        }
        
    }

    public void printGameResults1(int num){
        if(num <= 10){
            System.out.println("LOSS!\n" +wins+ " wins, " +losses+ " losses");
        }
        
    }

     public void printGameResults2(int num){
        if(num <= 10){
            System.out.println("WIN!\n" +wins+ " wins, " +losses+ " losses");
        }
        
    }

    public void printRoundPoint(int num){
        if(num <= 10){
            System.out.println("Point is " +roundPoint);
        }
        
    }

  
   


    
}
